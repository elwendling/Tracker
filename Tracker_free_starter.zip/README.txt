TRACKER — free starter app

This is a self-contained browser app. No paid services, accounts, or backend are required.

HOW TO USE
1. Open index.html in Safari/Chrome on a computer or phone.
2. Your entries are stored locally in that browser using localStorage.
3. To put it online for free later, upload index.html to a free static host such as GitHub Pages.

CURRENT STARTER FEATURES
- Home dashboard
- Unlimited mood entries with time/date and optional notes
- Mood history synced into Journal
- Schedule with saved dates
- Daily tasks and priority tasks
- Weekly budget categories
- Journal morning/night/general sections
- Daily/weekly/monthly/yearly goals with progress updates
- Nutrition meal logging and calorie/macros totals
- Cookbook categories and recipe creation
- Add cookbook recipes directly to today's meals

This is the first functional prototype. More polished icons, true calendar/history browsing, richer charts, reminders, photo uploads, and cloud sync can be added in later versions.
